bot_settings = {
    'Name': 'Детали для строительных и производственных компаний',
    'Username': 'coursework_bmstu_bot',
    'Token': open('C:/token.txt', 'r', encoding='utf-8').read()
}

database_settings = {
    'user': 'postgres',
    'password': '1111',
    'database': 'coursework',
    'host': 'localhost'
}